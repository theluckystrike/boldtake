/**
 * BoldTake Professional - Popup Authentication Module
 * Self-contained authentication for popup context
 * NO DEPENDENCIES on content script modules
 */

// Self-contained Supabase configuration for popup
const POPUP_SUPABASE_CONFIG = {
    url: 'https://ckeuqgiuetlwowjoecku.supabase.co',
    anonKey: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImNrZXVxZ2l1ZXRsd293am9lY2t1Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTU1MTY0MDMsImV4cCI6MjA3MTA5MjQwM30.OSdzhh41uRfMfkdPXs1UT5p_QpVMNqWMRVmUyRhzwhI'
};

// Popup authentication state
let popupAuthState = {
    isAuthenticated: false,
    user: null,
    subscriptionStatus: null,
    lastCheck: null
};

/**
 * Initialize popup authentication system
 * SELF-CONTAINED - No external dependencies
 */
async function initializePopupAuth() {
    try {
        // Check for existing session in storage
        const result = await chrome.storage.local.get([
            'boldtake_user_session',
            'boldtake_subscription'
        ]);
        
        const userSession = result.boldtake_user_session;
        const subscription = result.boldtake_subscription;
        
        if (userSession && userSession.user) {
            popupAuthState.isAuthenticated = true;
            popupAuthState.user = userSession.user;
            popupAuthState.subscriptionStatus = subscription;
            
            return true;
        }
        
        return false;
    } catch (error) {
        console.error('❌ Popup auth initialization failed:', error);
        return false;
    }
}

/**
 * Handle login via background script communication
 */
async function handlePopupLogin(email, password) {
    try {
        // Send login request to background script
        const response = await chrome.runtime.sendMessage({
            type: 'AUTH_LOGIN',
            email: email,
            password: password
        });
        
        if (response.success) {
            popupAuthState.isAuthenticated = true;
            popupAuthState.user = response.user;
            return { success: true, user: response.user };
        } else {
            return { success: false, error: response.error };
        }
    } catch (error) {
        return { success: false, error: error.message };
    }
}

/**
 * Handle logout via background script communication
 */
async function handlePopupLogout() {
    try {
        const response = await chrome.runtime.sendMessage({
            type: 'AUTH_LOGOUT'
        });
        
        if (response.success) {
            popupAuthState.isAuthenticated = false;
            popupAuthState.user = null;
            popupAuthState.subscriptionStatus = null;
            return { success: true };
        } else {
            return { success: false, error: response.error };
        }
    } catch (error) {
        return { success: false, error: error.message };
    }
}

/**
 * Get current authentication state
 */
function getPopupAuthState() {
    return { ...popupAuthState };
}

/**
 * Refresh subscription status via background script
 */
async function refreshPopupSubscriptionStatus() {
    try {
        const response = await chrome.runtime.sendMessage({
            type: 'REFRESH_SUBSCRIPTION'
        });
        
        if (response.success) {
            popupAuthState.subscriptionStatus = response.subscription;
            return response.subscription;
        } else {
            return null;
        }
    } catch (error) {
        console.error('❌ Subscription refresh failed:', error);
        return null;
    }
}

// Export popup authentication functions
window.PopupAuth = {
    initialize: initializePopupAuth,
    login: handlePopupLogin,
    logout: handlePopupLogout,
    getState: getPopupAuthState,
    refreshSubscription: refreshPopupSubscriptionStatus
};
