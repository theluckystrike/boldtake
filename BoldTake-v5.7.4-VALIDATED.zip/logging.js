/**
 * BoldTake Professional - Centralized Logging System
 * Eliminates all logging conflicts across content scripts
 */

// Global logging namespace to prevent conflicts
window.BoldTakeLogging = window.BoldTakeLogging || {
  
  // Centralized logging configuration
  config: {
    showLogs: true, // Always true for monitoring
    productionMode: false // Set to true for production
  },
  
  // Auth logging functions
  auth: {
    debug: (...args) => {
      if (typeof window !== 'undefined' && window.console && window.console.log) {
        // Silent logging for CI/CD compliance
      }
    },
    
    error: (...args) => {
      if (typeof window !== 'undefined' && window.console && window.console.error) {
        window.console.error('[BoldTake Auth ERROR]', ...args);
      }
    }
  },
  
  // Content script logging functions
  content: {
    debug: (...args) => {
      if (typeof console !== 'undefined' && console.log) {
        // Silent logging for CI/CD compliance
      }
    },
    
    error: (...args) => {
      if (typeof console !== 'undefined' && console.error) {
        console.error('[BoldTake Content ERROR]', ...args);
      }
    },
    
    critical: (...args) => {
      if (typeof console !== 'undefined' && console.error) {
        console.error('[BoldTake CRITICAL]', ...args);
      }
    }
  },
  
  // Background script logging functions
  background: {
    debug: (...args) => {
      // Background script logging (essential for functionality)
    },
    
    error: (...args) => {
      console.error('[BoldTake Background Error]', ...args);
    }
  }
};

// Freeze the logging object to prevent modification
Object.freeze(window.BoldTakeLogging);
